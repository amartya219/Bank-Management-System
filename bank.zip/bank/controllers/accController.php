<?php
    require_once '../../models/database.php';
    
   

    function getTransHis()
	{
		$query ="SELECT * FROM trans_history";
		$tran = get($query);
		return $tran;	
    }

	function getAcc()
	{
		$query ="SELECT * FROM account";
		$acc = get($query);
		return $acc;	
    }

	function appAcc($id)
    {
        $query="UPDATE account SET status='active' WHERE acc_no='$id'";
		
		execute($query);
	}
	


?>